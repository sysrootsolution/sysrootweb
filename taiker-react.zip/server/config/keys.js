module.exports = {
    stripePublishableKey: 'pk_test_ZaZZWZGlvdIn12yFleIqyjSI00G4e18Kf7',
    stripeSecretKey: 'sk_test_2DqyjEwaU0Nq0PpEMVQ3qSAw00zgrbnfPk'
};